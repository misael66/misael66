package cls;

public class clsMatriz {
    long DimensionFila;
    long DimensionColumna;

}
