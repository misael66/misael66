package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import cls.*;

public class formcadena extends JFrame{
    private clsCadena objcad = new clsCadena();
    
    private JLabel lblTitulo = new JLabel("Tipo de Datos Abstracto CADENA");
    private JLabel lblEntrada = new JLabel("Entrada:");
    private JLabel lblSalida = new JLabel("Salida:");
    private JTextField txtEntrada = new JTextField();
    private JTextField txtSalida = new JTextField();
    private JButton btnCargar = new JButton("Cargar");
    private JButton btnObtener = new JButton("Obtener");
    private JButton btntmay = new JButton("Todo a mayuscula");
    private JButton btntmin = new JButton("Todo a minuscula");
    private JButton btncantpalabras = new JButton("Cantidad de palabras");
    private JButton btnpalindrome = new JButton("Es palindrome");
    
   
    
    private JButton btnCerrar = new JButton("Cerrar");
    
    private clsUtilsGUI mUtils = new clsUtilsGUI();
    
    public formcadena() {
        try {
            objcad = new clsCadena();
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        formcadena frmcad = new formcadena();
        frmcad.setVisible(true);
    }   
    
    private void jbInit() throws Exception {
        int frmAncho = 515;
        int frmAlto = 500;

        //frmPrincipal:: Configurarción de las propiedades del Formulario
        getContentPane().setLayout(null);
        setSize(frmAncho, frmAlto);
        setTitle("TAD:: Clase Cadena");
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        
        //frmPrincipal:: Configuración de las propiedades de los objetos del Formulario
        lblTitulo.setBounds(new Rectangle(0, 5, frmAncho, 30));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));

        lblEntrada.setBounds(new Rectangle(10, 40, 50, 30));
        
        lblSalida.setBounds(new Rectangle(10, 80, 50, 30));
        
        txtEntrada.setBounds(new Rectangle(62, 40, 320, 30));
  
        txtSalida.setBounds(new Rectangle(62, 80, 430, 30));        
        
        btnCargar.setBounds(new Rectangle(390, 40, 100, 30));
        btnCargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnCargar_actionPerformed(e);
            }
        });
        
        btnObtener.setBounds(new Rectangle(10, 120, 150, 30));
        btnObtener.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnObtener_actionPerformed(e);
            }
        });        
        btntmay.setBounds(new Rectangle(170, 120, 150, 30));
        btntmay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btntmay_actionPerformed(e);
            }
        });
       
        btntmin.setBounds(new Rectangle(170, 175, 150, 30));
        btntmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btntmin_actionPerformed(e);
            }
        });
        btncantpalabras.setBounds(new Rectangle(10, 175, 150, 30));
        btncantpalabras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btncantpalabras_actionPerformed(e);
            }
        });
        btnpalindrome.setBounds(new Rectangle(330, 120, 150, 30));
        btnpalindrome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnpalindrome_actionPerformed(e);
            }
        });  
        
        
        
        
        
        
        btnCerrar.setBounds(new Rectangle(getWidth()-120, (getHeight()-70), 100, 30));
        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnCerrar_actionPerformed(e);
            }
        });
        
        
        
        
        getContentPane().add(lblTitulo, null);
        getContentPane().add(lblEntrada, null);
        getContentPane().add(lblSalida, null);
        getContentPane().add(txtEntrada, null); 
        getContentPane().add(txtSalida, null);
        getContentPane().add(btnCargar, null);
        getContentPane().add(btnObtener, null);
        getContentPane().add(btntmay, null);
        getContentPane().add(btntmin, null);
        getContentPane().add(btncantpalabras, null);
        getContentPane().add(btnpalindrome, null);
        
        
        getContentPane().add(btnCerrar, null);
        
    }
    private void btnCargar_actionPerformed(ActionEvent e) {           
        String c = ""+txtEntrada.getText();
        objcad.setCadena(c);
        txtSalida.setText("");
    }
    
    private void btnObtener_actionPerformed(ActionEvent e) {
        txtSalida.setText(objcad.getCadena());
    }
    private void btntmay_actionPerformed(ActionEvent e) {
        objcad.aMayuscula();        
        txtSalida.setText(objcad.getCadena());
    }
    private void btntmin_actionPerformed(ActionEvent e) {
        objcad.aMinuscula();        
        txtSalida.setText(objcad.getCadena());
    }
    private void btncantpalabras_actionPerformed(ActionEvent e) {       
        txtSalida.setText(""+objcad.CantidadPalabras());
    }
    private void btnpalindrome_actionPerformed(ActionEvent e) {       
        clsUtilsGUI mUtil = new clsUtilsGUI();
        if(objcad.espalindromo()){
            mUtil.msgbox("Es palindrome");
        }
        else{
            mUtil.msgbox("No es palindrome");
        }
    }
    private void btnCerrar_actionPerformed(ActionEvent e) {
        dispose();
    }
    
}
    
    