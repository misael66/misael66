package gui;

import gui.*;

public class runPrincipal {

    public static void main(String[] args) {
	// write your code here
        frmPrincipal frmP = new frmPrincipal();
        frmP.setVisible(true);
    }
}
