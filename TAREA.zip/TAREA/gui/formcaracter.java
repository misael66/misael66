package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;

import cls.*;

public class formcaracter extends JFrame {
    private clsCaracter objcar = new clsCaracter();
    private JLabel lblTitulo = new JLabel("Tipo de Datos Abstracto CARACTER");
    private JLabel lblEntrada = new JLabel("Entrada:");
    private JLabel lblSalida = new JLabel("Salida:");
    private JTextField txtEntrada = new JTextField();
    private JTextField txtSalida = new JTextField("");
    private JButton btnCargar = new JButton("Cargar");
    private JButton btnObtener = new JButton("Obtener");
    private JButton btnesmayuscula = new JButton("Es mayuscula");
    private JButton btnvocal = new JButton("Es vocal");
    private JButton btnamay = new JButton("Convertir a mayuscula");
    private JButton btnamin = new JButton("Convertir a minuscula");
    private JButton btnascii = new JButton("ASCII");
    private JButton btnCerrar = new JButton("Cerrar");
    public formcaracter() {
        try {
            objcar = new clsCaracter();
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        formcaracter frmcar = new formcaracter();
        frmcar.setVisible(true);
    }
    
    private void jbInit() throws Exception {
        int frmAncho = 515;
        int frmAlto = 500;

        

        //frmPrincipal:: Configurarción de las propiedades del Formulario
        getContentPane().setLayout(null);
        setSize(frmAncho, frmAlto);
        setTitle("TAD:: Clase Caracter");
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //frmPrincipal:: Configuración de las propiedades de los objetos del Formulario
        lblTitulo.setBounds(new Rectangle(0, 5, frmAncho, 30));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));

        lblEntrada.setBounds(new Rectangle(10, 40, 50, 30));
        
        lblSalida.setBounds(new Rectangle(10, 80, 50, 30));
        
        txtEntrada.setBounds(new Rectangle(62, 40, 50, 30));
  
        txtSalida.setBounds(new Rectangle(62, 80, 430, 30));
        
        btnCargar.setBounds(new Rectangle(122, 40, 150, 30));
        btnCargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnCargar_actionPerformed(e);
            }
        });
        
        btnObtener.setBounds(new Rectangle(10, 120, 150, 30));
        btnObtener.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnObtener_actionPerformed(e);
            }
        });
        btnesmayuscula.setBounds(new Rectangle(170, 120, 150, 30));
        btnesmayuscula.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnesmayuscula_actionPerformed(e);
            }
        });
        btnvocal.setBounds(new Rectangle(330, 175, 150, 30));
        btnvocal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnvocal_actionPerformed(e);
            }
        });
       
        btnamay.setBounds(new Rectangle(170, 175, 150, 30));
        btnamay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnamay_actionPerformed(e);
            }
        });
        
        btnamin.setBounds(new Rectangle(10, 175, 150, 30));
        btnamin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnamin_actionPerformed(e);
            }
        });
        btnascii.setBounds(new Rectangle(330, 120, 150, 30));
        btnascii.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnascii_actionPerformed(e);
            }
        });
        btnCerrar.setBounds(new Rectangle(getWidth()-120, (getHeight()-70), 100, 30));
        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnCerrar_actionPerformed(e);
            }
        });
        getContentPane().add(lblTitulo, null);
        getContentPane().add(lblEntrada, null);
        getContentPane().add(lblSalida, null);
        getContentPane().add(txtEntrada, null); 
        getContentPane().add(txtSalida, null);
        getContentPane().add(btnCargar, null);
        getContentPane().add(btnObtener, null);
        getContentPane().add(btnCerrar, null);
        getContentPane().add(btnesmayuscula, null);
        getContentPane().add(btnvocal, null);
        getContentPane().add(btnamay, null);
        getContentPane().add(btnamin, null);
        getContentPane().add(btnascii, null);
        
        
    }
    private void btnCargar_actionPerformed(ActionEvent e) { 
            String sDig = ""+txtEntrada.getText().charAt(0);
            //byte yDig = Byte.parseByte(sDig,16);
            char c=(char)sDig.charAt(0);
            objcar.setCaracter(c);
            txtSalida.setText("");
    }
    
    private void btnObtener_actionPerformed(ActionEvent e) {
        txtSalida.setText(objcar.aString());
    }
    private void btnesmayuscula_actionPerformed(ActionEvent e) {
        clsUtilsGUI mUtil = new clsUtilsGUI();
        if(objcar.Mayuscula()){
            mUtil.msgbox("Es mayuscula");
        }
        else {
            if(objcar.Minuscula()){
                mUtil.msgbox("Es minuscula");
            }else{
                 mUtil.msgbox("No es letra");
            }
        }
    }
    private void btnvocal_actionPerformed(ActionEvent e) {
        clsUtilsGUI mUtil = new clsUtilsGUI();
        if(objcar.vocal()){
            mUtil.msgbox("Es vocal");
        }
        else{
            mUtil.msgbox("No es vocal");
        }
    }
    private void btnamay_actionPerformed(ActionEvent e) {
        clsUtilsGUI mUtil = new clsUtilsGUI();
        if(objcar.Letra()){
            objcar.aMayuscula();
            txtSalida.setText("" +objcar.getCaracter());
        }else{
            mUtil.msgbox("No es letra");
        }
    }
    private void btnamin_actionPerformed(ActionEvent e) {
        clsUtilsGUI mUtil = new clsUtilsGUI();
        if(objcar.Letra()){
            objcar.aMinuscula();
            txtSalida.setText("" +objcar.getCaracter());
        }else{
            mUtil.msgbox("No es letra");
        }
    }
    private void btnascii_actionPerformed(ActionEvent e) {
        txtSalida.setText("" +objcar.ASCII());
    }
    
    private void btnCerrar_actionPerformed(ActionEvent e) {
        dispose();
    }
}
